PERMANENT WEBSITE SETUP (GitHub Pages)

Recommended repository name:
EthanDooh-gif.github.io

Upload these files to the ROOT of the repository (not inside another folder):
- index.html
- EE_Physics.pdf
- Ethan_Ekollo_Dooh_Resume.pdf
- Ethan_Ekollo_Dooh_CV_FR.pdf
- .nojekyll

Then in GitHub:
Settings > Pages > Build and deployment > Source: Deploy from a branch
Branch: main / (root) > Save

Your permanent website will then be:
https://ethandooh-gif.github.io/

Important: do not use file:///C:/... links on a public site. They only work on your own computer.
